#pragma once

#ifndef __CANCEL_EVENT_H_
#define __CANCEL_EVENT_H_
#include"Events/Event.h"
#include"Rest/Order.h"


class CancelEvent :public Event
{
public:
	CancelEvent(int currtime, int id);
	virtual void Execute(Restaurant* ptr);
};

#endif
