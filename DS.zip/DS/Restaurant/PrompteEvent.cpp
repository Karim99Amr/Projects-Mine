#include "PrompteEvent.h"
#include"Rest/Restaurant.h"


//PrompteEvent::PrompteEvent(){ ORD_TYPE Order_Type = TYPE_NRM;}

PrompteEvent::PrompteEvent(int ts, int id, double extr) : Event(ts, id)
{
	Extra_Mony = extr;

}

/*void PrompteEvent::setautopromotion(int c) {
	Auto_Promote_Time = c;
}*/

//move normal order to vip list and update order data
void PrompteEvent::Execute(Restaurant* ptr)
{
	ptr->Promote_with_extra_mony(OrderID, Extra_Mony);
	
}
