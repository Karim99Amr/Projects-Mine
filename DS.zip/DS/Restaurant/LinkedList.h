#pragma once

using namespace std;
#include <iostream>
#include "Generic_DS/Node.h"


template <typename T>
class LinkedList
{
private:
	Node<T>* Head;	//pointer to the head of the list

public:

	LinkedList()
	{
		Head = nullptr;
	}

	//list is being desturcted ==> delete all items in the list
	~LinkedList()
	{
		DeleteAll();
	}

	////////////////////////////////////////////////////////////////////////
	/*
	* Function: PrintList.
	* prints the values of all nodes in a linked list.
	*/

	void PrintList() const
	{
		Node<T>* p = Head;

		while (p)
		{
			cout << p->getItem() << " ";
			p = p->getNext();
		}
		cout << "";
	}

	/*
	* Function: InsertBeg.
	* Creates a new node and adds it to the beginning of a linked list.
	*
	* Parameters:
	*	- data : The value to be stored in the new node.
	*/

	void InsertBeg(const T& data)
	{
		Node<T>* R = new Node<T>(data);
		R->setNext(Head);
		Head = R;
	}

	/*
	* Function: DeleteAll.
	* Deletes all nodes of the list.
	*/

	void DeleteAll()
	{
		Node<T>* P = Head;
		while (Head)
		{
			P = Head->getNext();
			delete Head;
			Head = P;
		}
	}

	////////////////     Requirements   ///////////////////
	//
	// Implement the following member functions

	//[1]InsertEnd 
	//inserts a new node at end of the list
	void InsertEnd(const T& data)
	{
		Node<T>* p = Head;

		if (Head != nullptr)
		{
			while (p->getNext())
			{
				p = p->getNext();
			}
			Node<T>* R = new Node<T>(data);
			p->setNext(R);
		}
		else if (Head == nullptr)
		{
			InsertBeg(data);
		}
	}

	//[4] DeleteFirst
	//deletes the first node in the list
	void DeleteFirst() 
	{
		Node<T>* temp = new Node<T>;
		Node<T>* ptr = Head;
		Node<T>* ptr2 = Head;

		if (ptr == nullptr)
		{
			return;
		}

		temp = ptr;
		temp = nullptr;
		delete temp;

		Head = Head->getNext();
	}

	void DeleteNode(const T& value) 
	{
		Node<T>* ptr = Head;
		Node<T>* temp;
		Node<T>* prev;

		if (!ptr) 
		{
			return;
		}

		while (ptr && ptr->getItem() != value) 
		{
			prev = ptr;
			ptr = ptr->getNext();
		}

		if (ptr) 
		{
			if (ptr->getItem() == Head->getItem()) 
			{
				DeleteFirst();
			}
			else
			{
				temp = ptr;
				prev->setNext(ptr->getNext());
				ptr = prev;
				temp = nullptr;
				delete temp;
			}
		}

		if (!ptr) 
		{
			return;
		}
	}

	/*bool Search(int key)
	{
		bool k = false;
		Node<int>* ptr = Head;

		while (Head)
		{
			if (ptr->getItem() == Key)
			{
				k = true;
				cout << "found";
				break;
			}
		}
	}*/

};
