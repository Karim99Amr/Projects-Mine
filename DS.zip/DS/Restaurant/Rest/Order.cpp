#include "Order.h"


Order::Order(int id, ORD_TYPE r_Type, int x)
{
	ID = (id > 0 && id < 1000) ? id : 0;	//1<ID<999
	type = r_Type;
	VIPW = x;

	status = WAIT;
}

Order::~Order()
{

}

int Order::GetID()
{
	return ID;
}

void Order::setassignedcookID(int c) 
{
	assignedcookID = c;
}

int Order::getassignedcookid() const
{
	return assignedcookID;
}

ORD_TYPE Order::GetType() 
{
	return type;
}

void Order::SetDistance(int d)
{
	Distance = d > 0 ? d : 0;
}

void Order::setassignedcook(Cook* c)
{
	assignedcook = c;
}

Cook* Order::getassignedcook() 
{
	return assignedcook;
}

void Order::set_VIPWT(int x) 
{
	VIPW = x;
}

void Order::setautopromote(int x)
{
	autopromote = x;
}

int Order::getautopromote()
{
	return autopromote;
}

int Order::get_VIPWT()
{
	return VIPW;
}

int Order::GetDistance() const
{
	return Distance;
}

void Order::setStatus(ORD_STATUS s)
{
	status = s;
}

ORD_STATUS Order::getStatus() 
{
	return status;
}

void Order::SetArrTime(int a){ArrTime=a;}
int Order::GetArrTime()const{return ArrTime;}
	
void Order::SetServTime(int s){ServTime=s;}
int Order::GetServTime()const{return ServTime;}

void Order::SetFinishTime(int f){FinishTime=f;}
int Order::GetFinishTime()const{return FinishTime;}

void Order::SetTotalMoney(double m){totalMoney=m;}
double Order::GetTotalMoney()const{return totalMoney;}  
	
void Order::SetOrderSize(int s){OrderSize=s;}
int Order::GetOrderSize()const{return OrderSize;}

void Order::SetWaitingTime(int w){WaitingTime=w;}
int Order::GetWaitingTime()const{return WaitingTime;}

void Order::SetTotalOrders(int tO){TotalOrders=tO;}
int Order::GetTotalOrders()const{return TotalOrders;}

void Order::SetTotalNorm(int tN){TotalNorm=tN;}
int Order::GetTotalNorm()const{return TotalNorm;}

void Order::SetTotalVeg(int tG){TotalVeg=tG;}
int Order::GetTotalVeg()const{return TotalVeg;}

void Order::SetTotalVIP(int tV){TotalVIP=tV;}
int Order::GetTotalVIP()const{return TotalVIP;}

void Order::SetAvgWait(float AW){AvgWait=AW;}
float Order::GetAvgWait()const{return AvgWait;}

void Order::SetAvgServ(float AS){AvgServ=AS;}
float Order::GetAvgServ()const{return AvgServ;}

void Order::SetType(ORD_TYPE o) 
{
	type = o;
}

/*
Order& Order:: operator !=(Order o)
{
	ID = o.ID;
	type = o.type;
	OrderSize = o.OrderSize;
	totalMoney = o.totalMoney;
	ArrTime = o.ArrTime;
	return *this;
}/*

Order::Order(Order& o) 
{
	ID = o.ID;
	type = o.type;
	OrderSize = o.OrderSize;
	totalMoney = o.totalMoney;
	ArrTime = o.ArrTime;
}*/

Order::Order()
{

}

/*
float Order ::CalPiority(){
	priority= GetTotalMoney()/ GetOrderSize() +  1/ GetArrTime();
	return priority;
}

void Order::setPiority(float p){
	priority=p;
}

float  Order::getPiority(){
return priority;
}*/

void Order::setID(int i)
{
	ID = i;
}

void Order::set_order_priority() 
{
	Priority = GetTotalMoney() / GetOrderSize() + 1 / GetArrTime();
}

float Order::get_order_priority() 
{
	return Priority;
}

void Order::setassigntimestep(int t) 
{
	assigntime = t;
}

int Order::getassigntimestep() 
{
	return assigntime;
}

void Order::setoldfinishassign(int a) 
{
	oldfinishassign = a;
}

int Order::getoldfinishassign()
{
	return oldfinishassign;
}
