#ifndef __ORDER_H_
#define __ORDER_H_

#include "..\Defs.h"
#include"Cook.h"
using namespace std;


class Order
{
protected:
	int ID;              //each order has a unique ID (from 1 --> 999 )
	ORD_TYPE type;	    //order type: Normal, vegan, VIP
	ORD_STATUS status; //waiting, in-service, done
	int Distance;	  //the  distance (in meters) between the order location and the resturant 
	float Priority;  //vip order priority
	double totalMoney;	//total order money
	int VIPW;          //is urgent
	Cook* assignedcook;

	int ArrTime, assigntime , ServTime, FinishTime;	//arrival, service start, and finish times

	int OrderSize;
	int WaitingTime;
	int TotalOrders;
	int TotalNorm;
	int TotalVeg;
	int TotalVIP;
	float AvgWait;
	float AvgServ;
	int currenttime;
	int assignedcookID; //the id of the cook who prepare the order
	
	int  oldfinishassign; //time step the order was to finish before the cook injured
	int autopromote;

public:
	Order(int ID, ORD_TYPE r_Type, int VIPq);
	//Order& operator !=(Order o);
	//Order(Order& o);
	Order();
	virtual ~Order();
	
	int GetID();
	void set_order_priority();
	float get_order_priority();

	void set_VIPWT(int x);
	int get_VIPWT();

	void setassignedcook(Cook* c);
	Cook* getassignedcook();
	
	ORD_TYPE GetType() ;
	void SetType(ORD_TYPE o);
	void SetDistance(int d);
	int GetDistance() const;

	void setStatus(ORD_STATUS s);
	ORD_STATUS getStatus();
	
	//
	// TODO: Add More Member Functions As Needed
	//

	void SetArrTime(int a);
	int GetArrTime()const;

	void SetServTime(int s);
	int GetServTime()const;

	void SetFinishTime(int f);
	int GetFinishTime()const;

	void setassignedcookID(int);
	int getassignedcookid() const ;

	void SetTotalMoney(double m);
	double GetTotalMoney()const;   
	
	void SetOrderSize(int s);
	int GetOrderSize()const;

	void SetWaitingTime(int w);
	int GetWaitingTime()const;

	void setoldfinishassign(int);
	int getoldfinishassign();

	void SetTotalOrders(int tO);
	int GetTotalOrders()const;

	void SetTotalNorm(int tN);
	int GetTotalNorm()const;

	void SetTotalVeg(int tG);
	int GetTotalVeg()const;

	void SetTotalVIP(int tV);
	int GetTotalVIP()const;

	void SetAvgWait(float AW);
	float GetAvgWait()const;

	void setassigntimestep(int);
	int getassigntimestep();

	void SetAvgServ(float AS);
	float GetAvgServ()const;

	void setID(int i);

	void setautopromote(int);
	int getautopromote();

	//float getPiority();
	//void setPiority(float p);
	
	//float CalPiority();
};

#endif
