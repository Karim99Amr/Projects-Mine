#include "Order.h"
#include <fstream>
#include <iostream>
#include"Restaurant.h"
#include "..\CancelEvent.h"
#include "..\PrompteEvent.h"
#include "../Priority_Queue.h"
#include "..\Events\ArrivalEvent.h"


int Restaurant::NoOfevents = 0;
int Restaurant::Order_Waiting_Count = 0;
int Restaurant::Cook_Waiting_count = 0;
int Restaurant::Order_Serv_Count = 0;
int Restaurant::Order_Finish_Count = 0;
int Restaurant::Order_Urgent_Count = 0;
int Restaurant::Auto_Promotion_Count = 0;

int Restaurant::Normal_Order_Count = 0;
int Restaurant::Vegan_Order_Count = 0;
int Restaurant::VIP_Order_Count = 0;
//int Restaurant::Total_Order_Count = 0;
int Restaurant::Normal_Cook_Count = 0;
int Restaurant::Vegan_Cook_Count = 0;
int Restaurant::VIP_Cook_Count = 0;
int Restaurant::Total_Cook_Count = 0;
int Restaurant::Injured_Cook_Count = 0;
int Restaurant::arrived_order = 0;
int Restaurant::canceled_order = 0;
int Restaurant::promoted_order = 0;


int Restaurant::NormOrdersDone = 0;
int Restaurant::VegOrdersDone = 0;
int Restaurant::VIPOrdersDone = 0;

//recently added
int Restaurant::Available_Norm_cook = 0;
int Restaurant::Available_Vegan_cook = 0;
int Restaurant::Available_VIP_cook = 0;

int Restaurant::TotalNO = 0;
int Restaurant::TotalVO = 0;
int Restaurant::TotalGO = 0;

int  Restaurant::TotalNC = 0;
int  Restaurant::TotalVC = 0;
int  Restaurant::TotalGC = 0;
int Restaurant::promotedinprint = 0;

int Restaurant:: InServiceOrdersCount=0;


int Restaurant::OldN=0;
//function promote

Restaurant::Restaurant()
{
	pGUI = NULL;
	int arrived_order = 0;
	int canceled_order = 0;
	TimeStep = 1;
}

void Restaurant::RunSimulation()
{
	pGUI = new GUI;
	PROG_MODE mode = pGUI->getGUIMode();

	switch (mode)	//add a function for each mode in next phases
	{
	case MODE_INTR:
		SimulationForMODE(1);
		break;
	case MODE_STEP:
		SimulationForMODE(2);
		break;
	case MODE_SLNT:
		SimulationForMODE(3);
		break;
	};
}

void Restaurant::ExecuteEvents(int CurrentTimeStep)
{
	Event* pE;

	while (EventsQueue.peekFront(pE))	//as long as there are more events
	{
		if (pE->getEventTime() > CurrentTimeStep)	//no more events at current timestep
			return;

		pE->Execute(this);
		EventsQueue.dequeue(pE);	//remove event from the queue
		delete pE;		//deallocate event object from memory
	}
}

Restaurant::~Restaurant()
{
	if (pGUI) 
	{
		delete pGUI;
	}
}

void Restaurant::SetAvaillableNormalCook(Priority_Queue<Cook*> n) 
{
	AvailableNormCook = n;
}

void Restaurant::SetAvaillableVganCook(Priority_Queue<Cook*> n) 
{
	AvailableVegCook = n;
}

void Restaurant::SetAvaillableVIPCook(Priority_Queue<Cook*> n) 
{
	AvailableVIPCook = n;
}

Priority_Queue<Cook*> Restaurant::GetAvaillableNormalCook()
{
	return AvailableNormCook;
}

Priority_Queue<Cook*> Restaurant::GetAvaillableVIPCook() 
{
	return AvailableVIPCook;
}

Priority_Queue<Cook*> Restaurant::GetAvaillableVgancook() 
{
	return AvailableVegCook;
}

void Restaurant::SetWaitingNormalOrders(Queue<Order*> n)
{
	WaitingNormalOrders = n;
}

void Restaurant::SetWaitingVeganOrders(Queue<Order*> g)
{
	WaitingVeganOrders = g;
}

void Restaurant::SetWaitingVIPOrders(Priority_Queue<Order*> v)
{
	WaitingVIPOrders = v;
}

Queue<Order*> Restaurant::GetWaitingNormalOrder()
{
	return WaitingNormalOrders;
}

Queue<Order*> Restaurant::GetWaitingVeganOrder()
{
	return WaitingVeganOrders;
}

Priority_Queue<Order*> Restaurant::GetWaitingVIPorder()
{
	return WaitingVIPOrders;
}

void Restaurant::SetInServiceOrders(Queue<Order*> n)
{
	InServiceOrders=n;
}

Queue<Order*> Restaurant::GetInServiceOrders()
{
	return InServiceOrders;
}

void Restaurant::Add(Order *o)
{
	o->set_order_priority();
	float k = o->get_order_priority();

	if (o->GetType() == TYPE_NRM) 
	{
		WaitingNormalOrders.enqueue(o);
		//TotalNO++;
		//o->setStatus(WAIT);

	/*	Order_Waiting_Count++;
		Normal_Order_Count++;
		Total_Order_Count++;*/
	}
	else if (o->GetType() == TYPE_VGAN)
	{
		WaitingVeganOrders.enqueue(o);
		//o->setStatus(WAIT);
		/*Order_Waiting_Count++;
		Vegan_Order_Count++;
		Total_Order_Count++;*/
	}
	else 
	{
		WaitingVIPOrders.enqueue(o, k);
		//o->setStatus(WAIT);
		/*Order_Waiting_Count++;
		VIP_Order_Count++;
		Total_Order_Count++;*/
	}
}

void Restaurant::Setbusycook(Queue<Cook*> c) 
{
	BusyCooks = c;
}

Queue<Cook*>Restaurant::Getbusycooks()
{
	return BusyCooks;
}

void Restaurant::setCooksInBreak(Queue<Cook*> c)
{
	CooksInBreak = c;
}

Queue<Cook*>Restaurant::getCooksInBreak()
{
	return CooksInBreak;
}

void Restaurant::Addcook(Cook* c) 
{
	if (c->GetCookType() == COOK_TYPE_NRM) 
	{
		AvailableNormCook.enqueue(c, c->GetSpeed());
		Cook_Waiting_count++;
		Available_Norm_cook++;
	//	if (c->getiscountedbefore() == false) { // to make sure each cook will be counted once
		//Normal_Cook_Count++;
			//Total_Cook_Count++;
			//c->setiscountedbefore(true);
		//}
	}
	else if (c->GetCookType() == COOK_TYPE_VGAN) 
	{
		AvailableVegCook.enqueue(c, c->GetSpeed());
		Cook_Waiting_count++;
		Available_Vegan_cook++;
		//if (c->getiscountedbefore() == false) {
			//Vegan_Cook_Count++;
			//Total_Cook_Count++;
			//c->setiscountedbefore(true);
		//}
	}
	else
	{
		AvailableVIPCook.enqueue(c, c->GetSpeed());
		Cook_Waiting_count++;
		Available_VIP_cook++;
		//if (c->getiscountedbefore() == false) {
			//VIP_Cook_Count++;
			//Total_Cook_Count++;
			//c->setiscountedbefore(true);
		//}
	}
}

void Restaurant::Set_Rest_Cook(Queue<Cook*> c)
{
	Cooks_in_rest = c;
}

Queue<Cook*> Restaurant::Get_Rest_Cook()
{
	return Cooks_in_rest;
}

void Restaurant::AddToServiceOrders(Order* o)
{
	InServiceOrders.enqueue(o);
}

void Restaurant::AddToFinishedOrders(Order* o)
{
	FinishedOrders.enqueue(o);
}

void Restaurant::AddToUrgentOrders(Order* o)
{
	UrgentOrders.enqueue(o);
}

void Restaurant::CancelOrder(int id)
{
	Order* p;
	Queue<Order*>o;
	Queue<Order*>o2;

	if (!GetWaitingNormalOrder().isEmpty()) 
	{
		while (WaitingNormalOrders.dequeue(p))
		{
			if (p->GetID() == id)
			{
				o2.enqueue(p);
				Order_Waiting_Count--;
				canceled_order++;
				//Normal_Order_Count--;
			}
			else
				o.enqueue(p);
		}
		while (o.dequeue(p))
		{
			WaitingNormalOrders.enqueue(p);
		}
	}
	/*
	if (!GetWaitingVeganOrder().isEmpty()) 
	{
		while (WaitingVeganOrders.dequeue(p)) 
		{
			if (p->GetID() == id)
			{
				o2.enqueue(p);
				Order_Waiting_Count--;
				canceled_order++;
				Vegan_Order_Count--;
			}
			else 
				o.enqueue(p);
		}
		while (o.dequeue(p))
		{
			WaitingVeganOrders.enqueue(p);
		}
	}

	if (!GetWaitingVIPorder().isEmpty())
	{
		while (WaitingVIPOrders.dequeue(p))
		{
			if (p->GetID() == id)
			{
				o2.enqueue(p);
				Order_Waiting_Count--;
				canceled_order++;
				VIP_Order_Count--;
			}
			else 
				o.enqueue(p);
		}
		while (o.dequeue(p))
		{
			WaitingVIPOrders.cancelenqueue(p);
		}	
	}*/
}

int Restaurant::GetTimestep() 
{
	return TimeStep;
}

void Restaurant::LoadingFunction()
{
	ifstream inputFile;
	inputFile.open("TESTCASE5.txt");
	
	if (inputFile.is_open())
	{
		int n, g, v;
		inputFile >> n >> g >> v; //the number of cooks of different types

		Normal_Cook_Count = n;
		Vegan_Cook_Count = g;
		VIP_Cook_Count = v;
		TotalNC = n;
		TotalVC = v;
		TotalGC = g;
		Total_Cook_Count = n + g + v;

		float SN_min ,SN_max, SG_min, SG_max, SV_min, SV_max;
		inputFile >>SN_min >>SN_max>> SG_min>> SG_max>> SV_min>> SV_max;
		//min and max speed of each type

		float BO, BN_min, BN_max, BG_min, BG_max, BV_min ,BV_max;
		inputFile >> BO>> BN_min>> BN_max>> BG_min>> BG_max>> BV_min >>BV_max;
		//number of orders before break,
		//min and max break durations of each type

		float InjProp, RstPrd; 
		inputFile>>InjProp>> RstPrd;
		//the probability a busy cook gets injured and the rest period respectively

		//injured_Cook_Count=Total_Cook_Count*InjProp;

		int AutoP ,VIP_WT;
		inputFile>>AutoP >>VIP_WT;
		AutoPromo = AutoP;
		//AutoP: the number of ticks after which an order is automatically promoted to VIP 
		//VIP_WT: the number of ticks after which a VIP order is considered urgent

		int NoOfEvents;
		inputFile>>NoOfEvents;
		NoOfevents=NoOfEvents;
		//the number of events in this file

		Cook* c;
		ORD_TYPE type;
		int id = 1;
		
		for (int j = 1; j < n+1; j++)
		{
			c = new Cook(id, COOK_TYPE_NRM, SN_max, SN_min, BO, BN_max, BN_min, RstPrd, InjProp);
			Addcook(c);
			id++;
		}

		for (int k = 1; k < g + 1; k++)
		{
			c = new Cook(id, COOK_TYPE_VGAN, SV_max, SV_min, BO, BV_max, BV_min, RstPrd, InjProp);
			Addcook(c);
			id++;
		}

		for (int l = 1; l < v + 1; l++)
		{
			c = new Cook(id, COOK_TYPE_VIP, SV_max, SV_min, BO, BV_max, BV_min, RstPrd, InjProp);
			Addcook(c);
			id++;
		}

		Order* order;
		Event* Tevent;
		char check;
		int ID;
		char oType;

		for (int i = 0; i < NoOfEvents; i++)
		{
			inputFile >> check;

			if (check == 'R')
			{
				arrived_order++;
				int Size;
				int Money;
				inputFile >> oType;

				if (oType == 'N')
				{
					Normal_Order_Count++;
					type = TYPE_NRM;
					inputFile >> TimeStep >> ID >> Size >> Money;
					Tevent = new ArrivalEvent(TimeStep, ID, (ORD_TYPE)type, Size, Money, VIP_WT);
					EventsQueue.enqueue(Tevent);
					TotalNO++;
					OldN++;
					//order=new Order(ID,TYPE_NRM,1);
					//AllOrders.enqueue(order);
				}
				else if (oType == 'V')
				{
					VIP_Order_Count++;
					type = TYPE_VIP;
					inputFile >> TimeStep >> ID >> Size >> Money;
					Tevent = new ArrivalEvent(TimeStep, ID, (ORD_TYPE)type, Size, Money, VIP_WT);
					EventsQueue.enqueue(Tevent);
					TotalVO++;
					//order=new Order(ID,TYPE_NRM,1);
					//AllOrders.enqueue(order);
				}
				else if (oType == 'G')
				{
					Vegan_Order_Count++;
					type = TYPE_VGAN;
					inputFile >> TimeStep >> ID >> Size >> Money;
					Tevent = new ArrivalEvent(TimeStep, ID, (ORD_TYPE)type, Size, Money, VIP_WT);
					EventsQueue.enqueue(Tevent);
					TotalGO++;
					//	order=new Order(ID,TYPE_NRM,1);
						//AllOrders.enqueue(order);
				}
			}
			else if (check == 'X')
			{
				//canceled_order++;
				inputFile >> TimeStep >> ID;
				Tevent = new CancelEvent(TimeStep, ID);
				EventsQueue.enqueue(Tevent);
				Normal_Order_Count--;
				TotalNO--;
			}
			else if (check == 'P')
			{
				double ExMon;
				inputFile >> TimeStep >> ID >> ExMon;
				Tevent = new PrompteEvent(TimeStep, ID, ExMon);
				EventsQueue.enqueue(Tevent);
				TotalNO--;
				TotalVO++;
				//Normal_Order_Count--;
				//VIP_Order_Count++;
			}
		}
	}
	Order_Waiting_Count = VIP_Order_Count + Normal_Order_Count + Vegan_Order_Count;
	//Total_Order_Count = VIP_Order_Count + Normal_Order_Count + Vegan_Order_Count;
}
 
void Restaurant::FillDrawingList()
{
	int c, b, a = 0;
	int k, m, n = 0;
	int s, z = 0;

	Order** ord_arr = WaitingNormalOrders.toArray(a);
	Order** ord_arr2 = WaitingVeganOrders.toArray(b);
	Order** ord_arr3 = WaitingVIPOrders.toArray(c);
	Cook** nrmcook = AvailableNormCook.toArray(k);
	Cook** vgncook = AvailableVegCook.toArray(m);
	Cook** vipcook = AvailableVIPCook.toArray(n);
	Order** inservice = InServiceOrders.toArray(s);
	Order** finish = FinishedOrders.toArray(z);
	
	if (!GetWaitingNormalOrder().isEmpty())
	{
		for (int i = 0; i < a; i++) 
		{
			pGUI->AddToDrawingList(ord_arr[i]);
		}
	}

	if (!GetWaitingVeganOrder().isEmpty())
	{
		for (int i = 0; i < b; i++) 
		{
			pGUI->AddToDrawingList(ord_arr2[i]);
		}
	}

	if (!GetWaitingVIPorder().isEmpty())
	{
		for (int i = 0; i < c; i++) 
		{
			pGUI->AddToDrawingList(ord_arr3[i]);
		}
	}
	
	if (!GetAvaillableNormalCook().isEmpty())
	{
		for (int i = 0; i < k; i++) 
		{
			pGUI->AddToDrawingList(nrmcook[i]);
		}
	}

	if (!GetAvaillableVgancook().isEmpty()) 
	{
		for (int i = 0; i < m; i++) 
		{
			pGUI->AddToDrawingList(vgncook[i]);
		}
	}

	if (!GetAvaillableVIPCook().isEmpty())
	{
		for (int i = 0; i < n; i++) 
		{
			pGUI->AddToDrawingList(vipcook[i]);
		}
	}
	
	if (!InServiceOrders.isEmpty()) 
	{
		for (int i = 0; i < s; i++) 
		{
			pGUI->AddToDrawingList(inservice[i]);
			    
			 
		}
	}
	
	if (!FinishedOrders.isEmpty())
	{
		for (int i = 0; i < z; i++) 
		{
			pGUI->AddToDrawingList(finish[i]);
		}
	}

	pGUI->UpdateInterface();
	pGUI->ResetDrawingList();
}

//assigns an order to cook if he is available
bool Restaurant::ServeVIPOrders(int t)
{
	Cook* c;
	Order* o;
	//t = TimeStep;
	bool x = false;

	while (!WaitingVIPOrders.isEmpty())
	{
		if (!AvailableVIPCook.isEmpty())
		{
			WaitingVIPOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableVIPCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingVIPOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			VIP_Order_Count--;
			VIP_Cook_Count--;
			Available_VIP_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else if (!AvailableNormCook.isEmpty())
		{
			WaitingVIPOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableNormCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingVIPOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			Normal_Cook_Count--;
			VIP_Order_Count--;
			Available_Norm_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else if (!AvailableVegCook.isEmpty())
		{
			WaitingVIPOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableVegCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingVIPOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			Vegan_Cook_Count--;
			VIP_Order_Count--;
			Available_Vegan_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else
		{
			x = false;
			break;
		}
	}
	return x;
}

//assigns an order to cook if he is available
bool Restaurant::ServeNormOrders(int t)
{
	Cook* c;
	Order* o;
	//t = TimeStep;
	bool x = false;

	while (!WaitingNormalOrders.isEmpty())
	{
		if (!AvailableNormCook.isEmpty())
		{
			WaitingNormalOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableNormCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingNormalOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			Normal_Cook_Count--;
			Normal_Order_Count--;
			Available_Norm_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else if (!AvailableVIPCook.isEmpty())
		{
			WaitingNormalOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableVIPCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingNormalOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			VIP_Cook_Count--;
			Normal_Order_Count--;
			Available_VIP_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else
		{
			x = false;
			break;
		}
	}
	return x;
}

//assigns an order to cook if he is available
bool Restaurant::ServeVegOrders(int t)
{
	Cook* c;
	Order* o;
	//t = TimeStep;
	bool x = false;

	while (!WaitingVeganOrders.isEmpty())
	{
		if (!AvailableVegCook.isEmpty())
		{
			WaitingVeganOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableVegCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingNormalOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			Vegan_Cook_Count--;
			Vegan_Order_Count--;
			Available_Vegan_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else
		{
			x = false;
			break;
		}
	}
	return x;
}

//gives a cook his break after he finishes serving a specific number of orders
void Restaurant::AddCookToBreak(Cook* C, int t)
{
	if (C->Getordersdone() % C->GetBO() == 0)
	{
		if (C->CheckFirstISINJURED() == true)
		{
			C->setBreak(true);
			CooksInBreak.enqueue(C);
			C->SetBreakTimeStep(t);
			//C->setSpeed(C->GetSpeed() * 2);
			C->SetFirstISINJURED(false);
			C->setordersdone(0);
		}
		else
		{
			C->setBreak(true);
			CooksInBreak.enqueue(C);
			C->SetBreakTimeStep(t);
			C->setordersdone(0);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//remove order from cook and put the order and the cook in appropiate queue
void Restaurant::RemoveOrderFromCook(int t)
{
	Order* o;
	Cook* b;
	Queue<Cook*> q3;
	Queue<Order*> q2;

	while (!InServiceOrders.isEmpty()) 
	{
		InServiceOrders.dequeue(o);

		if (o->GetServTime() + o->GetArrTime() + o->GetWaitingTime() == t && o->getassignedcook()->CheckFirstISINJURED() == false)
		{
			o->setStatus(DONE);
			FinishedOrders.enqueue(o);
			o->getassignedcook()->incrementordersdone();
			o->SetFinishTime(o->GetServTime() + o->GetArrTime() + o->GetWaitingTime());
			Order_Finish_Count++;  //Nermeen

			/////////////////////////////////////Nermeen
			if (o->GetType() == TYPE_VIP)
			{
				VIPOrdersDone++;
			}
			if (o->GetType() == TYPE_VGAN)
			{
				VegOrdersDone++;
			}
			if (o->GetType() == TYPE_NRM)
			{
				NormOrdersDone++;
			}
			/////////////////////////////////////

			while (BusyCooks.dequeue(b))
			{
				if (b->GetID() == o->getassignedcookid())
				{
					if (b->GetBO() > b->Getordersdone())
					{
						Addcook(b);
					}
					else
					{
						AddCookToBreak(b, t);
					}
				}
				else 
					q3.enqueue(b);
			}
		}
		else q2.enqueue(o);
	}

	while (q2.dequeue(o)) 
	{
		InServiceOrders.enqueue(o);
	}

	while (q3.dequeue(b))
	{
		BusyCooks.enqueue(b);
	}
}




void Restaurant::RemoveOrderFromCookEmergencyCase(int t) 
{
	Order* o;
	Cook* b;
	Queue<Cook*> q3;
	Queue<Order*> q2;

	if (!InServiceOrders.isEmpty())
	{
		while(InServiceOrders.dequeue(o))
		{
			if (2 * o->getoldfinishassign() - o->getassignedcook()->getinjurytime() == t && o->getassignedcook()->CheckFirstISINJURED() == true)
			{
				o->setStatus(DONE);
				FinishedOrders.enqueue(o);
				o->getassignedcook()->incrementordersdone();
				o->SetFinishTime(2 * o->getoldfinishassign() - o->getassignedcook()->getinjurytime()+o->GetArrTime());
				o->SetServTime(o->GetFinishTime() - o->getassigntimestep());
				Order_Finish_Count++;  //Nermeen

				while (BusyCooks.dequeue(b))
				{
					if (b->GetID() == o->getassignedcook()->GetID())
					{
						if (b->GetBO() > b->Getordersdone())
						{
							Cooks_in_rest.enqueue(b);
							b->SetFirstISINJURED(false);
							b->SetRestTimeStep(t);
						}
						else AddCookToBreak(b, t);
					}
					else
						q3.enqueue(b);
				}
			}
			else q2.enqueue(o);
				//}
			//}
			
		}
		//}
		//else q2.enqueue(o);
	}

	while (q2.dequeue(o))
	{
		InServiceOrders.enqueue(o);
	}
	while (q3.dequeue(b)) 
	{
		BusyCooks.enqueue(b);
	}
}

//////////////////////////////////////////~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~////////////////////  /////////////////////////
/////////////////////////////~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~/////////////////////	/////////////////////////
	
void Restaurant::RemoveCookFromBreak(int t)
{
	Cook* c;
	Queue<Cook*>q3;
	
	while (!CooksInBreak.isEmpty()) 
	{
		CooksInBreak.dequeue(c);

		if (t == c->getbreakduration() + c->GetBreakTimeStep())
		{
			Addcook(c);
			c->setBreak(false);
		}
		else 
			q3.enqueue(c);
	}

	while (q3.dequeue(c))
	{
		CooksInBreak.enqueue(c);
	}
}

//remove cooks from rest queue to their queues depending on their type
void Restaurant::RemoveCOOKFROMREST(int t)
{
	Cook* c;
	Queue<Cook*> q2;

	while (Cooks_in_rest.dequeue(c))
	{
		if ( t == (c->GetRestTimeStep() + c->GetRestPeriod() + 1))
		{
			Addcook(c);
		}
		else
			q2.enqueue(c);
	}

	while (q2.dequeue(c))
	{
		Cooks_in_rest.enqueue(c);
	}
}

/////////////////////////////////////////~~~~~~~~~~~~~~~~~~~~~~~~~~~///////////////////////*

//will be handeled in function REMOVE_ORDER_FROM_COOK here we just set speedto half and set the cook injured 
void Restaurant::HealthProblem(int t) 
{
	Cook* c;
	srand(time(0));
	float k = (rand() % 100 + 1);
	float R = k / 100;

	if (BusyCooks.peekFront(c))
	{
		if (R <= c->GetInjuryProp() && c->CheckFirstISINJURED() == false)
		{
			c->setSpeed(c->GetSpeed() * 0.5);
			c->SetFirstISINJURED(true);
			c->setinjurytime(t);
			Injured_Cook_Count++;
		}
	}
	else 
		return;
}

//////////////////////////~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

//promotion Event functions 

void Restaurant::Promote_with_extra_mony(int id, double extramony)
{
	Queue<Order*> q2;
	Order* o;

	if (!WaitingNormalOrders.isEmpty()) 
	{
		while (WaitingNormalOrders.dequeue(o)) 
		{
			if (o->GetID() == id)
			{
				o->SetTotalMoney(o->GetTotalMoney() + extramony);
			//	o->set_order_priority();
			//	float k = o->get_order_priority();
				o->SetType(TYPE_VIP);
				o->setStatus(WAIT);
				Add(o);
				//WaitingVIPOrders.enqueue(o, k);
				//VIP_Order_Count++;
				//Normal_Order_Count--;
				promoted_order++;
			}
			else
			{
				q2.enqueue(o);
			}
		}
		
	}

	while (q2.dequeue(o))
	{
		WaitingNormalOrders.enqueue(o);
	}
}

void Restaurant::AutoPromote(int t)
{	
	Order* o;
	Queue<Order*>q2;
	//Queue<Order*>q;
	
	while (WaitingNormalOrders.dequeue(o))
	{
		if (t == o->GetArrTime() + AutoPromo)
		{
			o->set_order_priority();
			float k = o->get_order_priority();
			o->SetType(TYPE_VIP);
			o->setStatus(WAIT);
			WaitingVIPOrders.enqueue(o, k);
			Auto_Promotion_Count++;
			promoted_order++;
			VIP_Order_Count++;
			Normal_Order_Count--;
		}
		else 
			q2.enqueue(o);
	}

	while (q2.dequeue(o)) 
	{
		WaitingNormalOrders.enqueue(o);
	}
	/*
	while (!GetWaitingNormalOrder().isEmpty()) {
		WaitingNormalOrders.dequeue(o);

		if (o->GetArrTime() + AutoPromo == t) {
			
			o->SetType(TYPE_VIP);
			o->set_order_priority();
			o->get_order_priority();
				WaitingVIPOrders.enqueue(o,o->get_order_priority());
			Auto_Promotion_Count++;
			promoted_order++;
			VIP_Order_Count++;
			Normal_Order_Count--;
		}
		else q2.enqueue(o);

	}
	while (q2.dequeue(o))
	{
		WaitingNormalOrders.enqueue(o);
	}*/
	//while (!q.isEmpty()) {
	//	q.dequeue(o);
	//}
}

/////////////////////////////////////////////////////////////////////////////////////////

//converts the VIP orders that waited longer than VIP_WT ticks into urgent orders
void Restaurant::isUrgent(int t)
{
	Order* o;
	Queue<Order*> q1;

	while (!WaitingVIPOrders.isEmpty())
	{
		WaitingVIPOrders.dequeue(o);

		if ((t - o->GetArrTime()) > o->get_VIPWT())
		{
			UrgentOrders.enqueue(o);
			Order_Urgent_Count++;
		}
		else
		{
			q1.enqueue(o);
		}
	}

	while (q1.dequeue(o))
	{
		WaitingVIPOrders.enqueue(o, o->get_order_priority());
	}
}

//handles the VIP orders that waited longer than VIP_WT ticks
//these orders are considered urgent and must be served (urgent orders)
//even using cooks that are in break or in rest
bool Restaurant::ServeUrgentOrders(int t)
{
	Cook* c;
	Order* o;
	//t = TimeStep;
	bool x = false;

	while (!UrgentOrders.isEmpty())
	{
		if (!AvailableVIPCook.isEmpty())
		{
			UrgentOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableVIPCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingVIPOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			VIP_Cook_Count--;
			Available_VIP_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else if (!AvailableNormCook.isEmpty())
		{
			UrgentOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableNormCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingVIPOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			Normal_Cook_Count--;
			Available_Norm_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else if (!AvailableVegCook.isEmpty())
		{
			UrgentOrders.dequeue(o);
			o->setStatus(SRV);

			AvailableVegCook.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingVIPOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			Vegan_Cook_Count--;
			Available_Vegan_cook--;
			Cook_Waiting_count--;  //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;   //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);

			x = true;
		}
		else if (!CooksInBreak.isEmpty())
		{
			UrgentOrders.dequeue(o);
			o->setStatus(SRV);

			CooksInBreak.dequeue(c);
			BusyCooks.enqueue(c);

			//WaitingVIPOrders.dequeue(o);
			InServiceOrders.enqueue(o);

			//Available_Vegan_cook--;
			//Cook_Waiting_count--; //decreasing the queue of available/waiting cooks
			Order_Serv_Count++;    //increasing the queue of orders being served

			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);
			c->setBreak(false);

			x = true;
		}
		else if (!Cooks_in_rest.isEmpty())
		{
		    UrgentOrders.dequeue(o);
		    o->setStatus(SRV);

			Cooks_in_rest.dequeue(c);
		    BusyCooks.enqueue(c);

		    //WaitingVIPOrders.dequeue(o);
		    InServiceOrders.enqueue(o);

		    //Available_Vegan_cook--;
		    //Cook_Waiting_count--; //decreasing the queue of available/waiting cooks
		    Order_Serv_Count++;    //increasing the queue of orders being served
			
			int ordertime;
			ordertime = o->GetOrderSize() / c->floattoint(c->GetSpeed()); //c->GetSpeed();
			o->SetWaitingTime(t - o->GetArrTime());
			o->SetServTime(ordertime);
			o->setassigntimestep(t);
			int g = o->getassigntimestep();
			int f = o->GetServTime();
			o->setoldfinishassign(g + f);
			o->setassignedcook(c); //mostafa
			o->setassignedcookID(c->GetID()); //mostafa
			//o->SetFinishTime(ordertime + TimeStep);
		    c->setBreak(false);
			
			x = true;
		}
		else
		{
			x = false;
			break;
		}
	}
	return x;
}

float Restaurant::Get_Percentageof_Auto_Promot() 
{
	float x = (tofloat(Auto_Promotion_Count)/tofloat(OldN) ) * 100;
	return x;
}

float Restaurant:: tofloat(int x) {
	float z = x;
	return z;
}


void Restaurant::PrintingFunction()
{

	float AvgWait;
	float AvgServ;
	//int AutoPromotedPercentage;
	Order* doneOrders;
	float WaitingTime = 0;
	float servingTime = 0;
	
	/////////
	int ID_Done = -1;
	Order* peekFirstDone;
	Order* temp_done;
	Order* firstOrderDone;
	int firstOrderDoneID;
	int numF = 0;
	FinishedOrders.peekFront(firstOrderDone);
	if (!FinishedOrders.isEmpty())
	{
		firstOrderDoneID = firstOrderDone->GetID();
	}
	else
		firstOrderDoneID = -1;

	while (firstOrderDoneID != ID_Done)
	{
		FinishedOrders.dequeue(temp_done);
		WaitingTime += temp_done->GetWaitingTime();
		servingTime += temp_done->GetServTime();
		numF++;
		FinishedOrders.enqueue(temp_done);
		FinishedOrders.peekFront(peekFirstDone);
		ID_Done = peekFirstDone->GetID();


	}


	AvgWait = WaitingTime / numF;
	AvgServ = servingTime / numF;
	
	
//	AutoPromotedPercentage = (Auto_Promotion_Count / TotalNO);


	ofstream Output;
	Output.open("Output");

	Output << "FT          ID          AT          WT          ST";
	Output << "\n";
	Priority_Queue<Order*> doneToOutPut;
	while (FinishedOrders.dequeue(doneOrders))
	{
		doneToOutPut.enqueue(doneOrders, doneOrders->GetWaitingTime() + doneOrders->GetServTime());

	}
	while (doneToOutPut.dequeue(doneOrders))
	{

		Output << doneOrders->GetWaitingTime() + doneOrders->GetServTime()+doneOrders->GetArrTime() << "          " << doneOrders->GetID() << "          " << doneOrders->GetArrTime() << "          " << doneOrders->GetWaitingTime() << "          " << doneOrders->GetServTime();
		Output << "\n";

	}


	Output << "\n";
	
	Output << "Orders: " << TotalNO+TotalGO+TotalVO;
	Output << "[norm: " << TotalNO;
	Output << ",veg: " << TotalGO;
	Output << ",Vip: " << TotalVO;
	Output << "]";
	Output << "\n";
	Output << "Cooks : " << Total_Cook_Count;
	Output << "[Norm:" << TotalNC;
	Output << ",veg:" << TotalGC;
	Output << ",Vip:" << TotalVC;
	Output << ",injured" << Injured_Cook_Count;
	Output << "]";
	Output << "\n";

	Output << "Avg Wait = " << AvgWait;
	Output << "    ";
	Output << ",Avg_ST = " << AvgServ;
	Output << "\n";

	Output << " Urgent orders: " << Order_Urgent_Count;
	Output << " ";
	Output << ",Auto-promoted:" << " " << Get_Percentageof_Auto_Promot();
		;
	Output << "%";




}

int Restaurant::Count_Waiting_Normal() {
	int c = 0;
	Order* o;
	Queue<Order*> q1;
	while (WaitingNormalOrders.dequeue(o)) {
		c = c + 1;
		q1.enqueue(o);
	}
	while (q1.dequeue(o)) {
		WaitingNormalOrders.enqueue(o);
	}
	return c;
}



int Restaurant::Count_Waiting_VGN() {
	int c = 0;
	Order* o;
	Queue<Order*> q1;
	while (WaitingVeganOrders.dequeue(o)) {
		c = c + 1;
		q1.enqueue(o);
	}
	while (q1.dequeue(o)) {
		WaitingVeganOrders.enqueue(o);
	}
	return c;
}

int Restaurant::Count_Waiting_VIP() {
	int c = 0;
	Order* o;
	Priority_Queue<Order*> q1;
	while (WaitingVIPOrders.dequeue(o)) {
		c = c + 1;
		//o->set_order_priority();
		//float k = o->get_order_priority();
		q1.cancelenqueue(o);
	}
	while (q1.dequeue(o)) {
		WaitingVIPOrders.cancelenqueue(o);
	}
	return c;
}






 
void Restaurant::SimulationForMODE(int mode)
{
	
	LoadingFunction();
	Event* current_event;
	Order* gettingServiced;
	int x = 1;
	TimeStep = 1;
	
	int Old_s=0;//index
	while (EventsQueue.peekFront(current_event) || InServiceOrders.peekFront(gettingServiced) || WaitingVIPOrders.peekFront(gettingServiced) || WaitingVeganOrders.peekFront(gettingServiced) || WaitingNormalOrders.peekFront(gettingServiced))
	{       
		if(mode!=3){

				pGUI->PrintMessage(" Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));}
				
				//1	if(mode==1)
				//pGUI->waitForClick();
			    
	//	else Sleep(1000);
	

	





		
		//for(int i=x;i<TimeStep;i++)
		//{
		while (EventsQueue.peekFront(current_event) && current_event->getEventTime() == x)
		{
			EventsQueue.dequeue(current_event);

			if (current_event == dynamic_cast<CancelEvent*> (current_event))
			{
				current_event->Execute(this);
				//canceled_order++;
				
					pGUI->PrintMessage(" Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));




			}
			else if (current_event == dynamic_cast<ArrivalEvent*> (current_event))
			{
				current_event->Execute(this);
				arrived_order++;

						
					pGUI->PrintMessage(" Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));




				int s;//size
					
				Order** inservice = InServiceOrders.toArray(s);//size
				if (!InServiceOrders.isEmpty()&&mode!=3) 
				{  
					
					if(Old_s!=s){
					
						

		while( Old_s<s-1|| Old_s==s-1  ) 
		{  
				


     		   Order* OrderAssignedToACook;
	            ORD_TYPE t_O;// ORDER TYPE
				COOK_TYPE t_C;//COOK TYPE
				int I_D_O;//ID OF ORDER
				int I_D_C;//ID OF COOK
	

					OrderAssignedToACook=inservice[Old_s];
				t_O=OrderAssignedToACook->GetType();
				I_D_O=OrderAssignedToACook->GetID();
				I_D_C=OrderAssignedToACook->getassignedcookid();
				t_C=OrderAssignedToACook->getassignedcook()->GetCookType();

			



				if(t_O==TYPE_NRM)


				{ 
					if(t_C==COOK_TYPE_NRM){pGUI->PrintMessage("N"+to_string(I_D_C)+"(N"+to_string(I_D_O)+")"	+	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000);
 }


				else pGUI->PrintMessage("V"+to_string(I_D_C)+"(N"+to_string(I_D_O)+")"+	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000);  
					
				}
				

				if(t_O==TYPE_VGAN)
				{ pGUI->PrintMessage("G"+to_string(I_D_C)+"(G"+to_string(I_D_O)+")"+	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000);
					 
				}



				if(t_O==TYPE_VIP)
				{ if(t_C==COOK_TYPE_NRM){pGUI->PrintMessage("N"+to_string(I_D_C)+"(V"+to_string(I_D_O)+")"  +	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000);}
				else if(t_C==COOK_TYPE_VIP){ pGUI->PrintMessage("V"+to_string(I_D_C)+"(V"+to_string(I_D_O)+")"  +	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000); 
					
				}  else 	if(t_C==TYPE_VGAN)
				{ pGUI->PrintMessage("G"+to_string(I_D_C)+"(V"+to_string(I_D_O)+")"+	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000);
					 
				}
				}
Old_s++;
} 	Old_s=s;
}


				
		}




			}
			else if (current_event == dynamic_cast<PrompteEvent*>(current_event))
			{
				current_event->Execute(this);
				//promoted_order++;
						
					pGUI->PrintMessage(" Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));



				int s;//size
					
				Order** inservice = InServiceOrders.toArray(s);//size
				if (!InServiceOrders.isEmpty()&&mode!=3) 
				{  
					
					if(Old_s!=s){
					
						

		while( Old_s<s-1|| Old_s==s-1  ) 
		{  
				


     		   Order* OrderAssignedToACook;
	            ORD_TYPE t_O;// ORDER TYPE
				COOK_TYPE t_C;//COOK TYPE
				int I_D_O;//ID OF ORDER
				int I_D_C;//ID OF COOK
	

					OrderAssignedToACook=inservice[Old_s];
				t_O=OrderAssignedToACook->GetType();
				I_D_O=OrderAssignedToACook->GetID();
				I_D_C=OrderAssignedToACook->getassignedcookid();
				t_C=OrderAssignedToACook->getassignedcook()->GetCookType();

			



			


if(t_O==TYPE_VIP)
				{ if(t_C==COOK_TYPE_NRM){pGUI->PrintMessage("N"+to_string(I_D_C)+"(V"+to_string(I_D_O)+")"  +	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000);}
				else if(t_C==COOK_TYPE_VIP){ pGUI->PrintMessage("V"+to_string(I_D_C)+"(V"+to_string(I_D_O)+")"  +	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000); 
					
				}  else 	if(t_C==TYPE_VGAN)
				{ pGUI->PrintMessage("G"+to_string(I_D_C)+"(V"+to_string(I_D_O)+")"+	"   Current TimeStep:  " + to_string(x) , 
			+ "   Waiting Orders: VIP  Vegan  Normal  "
			+ to_string(Count_Waiting_VIP()) + "  "
			+ to_string(Count_Waiting_VGN()) + "  "
			+ to_string(Count_Waiting_Normal()) ,

			+ "   Available Cooks: VIP  Vegan  Normal  "
			+ to_string(Available_VIP_cook) + "  "
			+ to_string(Available_Vegan_cook) + "  "
			+ to_string(Available_Norm_cook) ,

			+ "   Auto Promoted: " + to_string(Auto_Promotion_Count)
			+ ".  Urgent Orders: " + to_string(Order_Urgent_Count)
			+ ".  Injured Cooks: " + to_string(Injured_Cook_Count)
			+ "   Orders Done: " + to_string(Order_Finish_Count));
		if(mode==1)
				pGUI->waitForClick();
			    
		else Sleep(1000);
					 
				}
				}
				
Old_s++;
} 	Old_s=s;
}


				
		}








			}
		}
		//}
		if (mode == 1)
		{  

			ActionFunction();
			FillDrawingList();
			
			
			
			pGUI->waitForClick();

			if (x > TimeStep )
			{
				break;
			}
			else
				x++;
			
		}
		else if (mode == 2)
		{
			
			ActionFunction();
			FillDrawingList();
			Sleep(1000); //a built-in function that suspends the exection of the program for a specific period of time
			if (x>TimeStep) break;
			else
			x++;	
		
		}
		else if (mode == 3)
		{  
			ActionFunction();
			if (x>TimeStep) break;
			else
			x++;
			
		}
	
		TimeStep++;
	}
	PrintingFunction();
}





void Restaurant::ActionFunction()
{
	RemoveOrderFromCook(TimeStep);
	RemoveOrderFromCookEmergencyCase(TimeStep);
	RemoveCOOKFROMREST(TimeStep);
	RemoveCookFromBreak(TimeStep);
	AutoPromote(TimeStep);
	isUrgent(TimeStep);
	ServeUrgentOrders(TimeStep);
	ServeVIPOrders(TimeStep);
	ServeVegOrders(TimeStep);
	ServeNormOrders(TimeStep);
	HealthProblem(TimeStep);
	
}
