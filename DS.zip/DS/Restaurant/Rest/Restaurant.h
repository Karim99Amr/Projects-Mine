#ifndef __RESTAURANT_H_
#define __RESTAURANT_H_

#include "..\Defs.h"
#include "..\CMUgraphicsLib\CMUgraphics.h"
#include "..\GUI\GUI.h"
#include "..\Generic_DS\Queue.h"
#include "..\Events\Event.h"
#include "..\Priority_Queue.h"
#include "Order.h"
#include"..\LinkedList.h"
#include<cstdlib>
#include<ctime>


//it is the maestro of the project
class Restaurant  
{	
private:
	GUI *pGUI;
	Queue<Event*> EventsQueue;	//queue of all events that will be loaded from file
	int numinsametimestep;
	int arrivedEvents;
	static int NoOfevents;

	static int arrived_order;
	static int canceled_order;
	static int promoted_order;
	
	//int finished_Orders;
	static int TotalNO;
	static int TotalVO;
	static int TotalGO;
	static int TotalNC;
	static int TotalVC;
	static int TotalGC;
	static int promotedinprint;


	static int Cook_Waiting_count;     //number of cooks waiting/availabe to receive orders
	static int Order_Serv_Count;      //number of orders being served
	static int Order_Finish_Count;   //number of finished/served orders
	static int Order_Urgent_Count;  //number of urgent orders
	int TimeStep;

	//number of finished orders
	static int NormOrdersDone;
	static int VegOrdersDone;
	static int VIPOrdersDone;

	//number of waiting orders
	static int Order_Waiting_Count;  //total number of orders waiting to be served
	static int Normal_Order_Count;
	static int Vegan_Order_Count;
	static int VIP_Order_Count;
	//static int Total_Order_Count;

	//numbers related to outpufile
	static int Injured_Cook_Count;
	static int Auto_Promotion_Count;  //will be used in function which calculate the percentage Read next line!!!
	//very important Note!!!!!-----> to know the percentage of autopromotion call function "Get_Percentageof_Auto_Promot() "

	//number of available cooks taken from text files
	static int Normal_Cook_Count;
	static int Vegan_Cook_Count;
	static int VIP_Cook_Count;
	static int Total_Cook_Count;

	//needed for modes to alter in value
	static int Available_Norm_cook;
	static int Available_Vegan_cook;
	static int Available_VIP_cook;

	static int InServiceOrdersCount;
	static int OldN;

	int AutoPromo;

	//availlable cooks
	Priority_Queue<Cook*> AvailableNormCook;
	Priority_Queue<Cook*> AvailableVegCook;
	Priority_Queue<Cook*> AvailableVIPCook;
	
	//queue of busy cooks 
	Queue<Cook*> BusyCooks;

	//queue of in-break cooks
	Queue<Cook*> CooksInBreak;

	//queue of cooks who was injured and in rest
	Queue<Cook*> Cooks_in_rest;

	//queue of waiting orders 
	Queue<Order*> WaitingNormalOrders;
	Queue<Order*> WaitingVeganOrders;
	Priority_Queue<Order*> WaitingVIPOrders;

	//queue of inservice orders
	Queue<Order*> InServiceOrders;

	//queue of finished orders 
	Queue<Order*> FinishedOrders;

	//queue of urgent orders 
	Queue<Order*> UrgentOrders;

	Queue<Order*> AllOrders;

public:
	Restaurant();
	~Restaurant();

	void ExecuteEvents(int TimeStep);	//executes all events at current timestep
	void RunSimulation();
	void FillDrawingList();

	//FILE LOADING 
	void LoadingFunction();

	void SetWaitingNormalOrders(Queue< Order* > n);
	void SetWaitingVeganOrders(Queue<Order* > g);
	void SetWaitingVIPOrders(Priority_Queue<Order*> v);
	Queue<Order* > GetWaitingNormalOrder();
	Queue<Order* > GetWaitingVeganOrder();
	Priority_Queue<Order*> GetWaitingVIPorder();

	//PUT THE ORDER TO INSERVICE QUEUE
	void SetInServiceOrders(Queue< Order*> n);
	void AddToServiceOrders(Order* o);
	Queue<Order* > GetInServiceOrders();

	//PUT THE ORDER TO FINISHED QUEUE
	void AddToFinishedOrders(Order* o);

	//PUT THE ORDER TO URGENT QUEUE
	void AddToUrgentOrders(Order* o);

	void SetAvaillableNormalCook(Priority_Queue<Cook*> n);
	void SetAvaillableVganCook(Priority_Queue<Cook*> n);
	void SetAvaillableVIPCook(Priority_Queue<Cook*> n);
	Priority_Queue<Cook*> GetAvaillableNormalCook();
	Priority_Queue<Cook*> GetAvaillableVIPCook();
	Priority_Queue<Cook*> GetAvaillableVgancook();

	//get time step in promotion
	int GetTimestep();
	float tofloat(int);
	
	//SET AND GET BUSY COOKS
	void Setbusycook(Queue<Cook*>);
	Queue<Cook*> Getbusycooks();

	//SET AND GET IN-BREAKCOOKS
	void setCooksInBreak (Queue<Cook*>);
	Queue<Cook*> getCooksInBreak();
	
	//SET AND GET REST COOKS
	void Set_Rest_Cook(Queue<Cook*>);
	Queue<Cook*> Get_Rest_Cook();
	
	//Nermeen
	//bool AddOrderToCook(Order* o);
	bool ServeVIPOrders(int);
	bool ServeNormOrders(int);
	bool ServeVegOrders(int);
	void AddCookToBreak(Cook*, int);
	void isUrgent(int);
	bool ServeUrgentOrders(int);

	//NEW FUNCTIONS by MOSTAFA NEDDAL 
	void Addcook(Cook*);  //put the cook in AVaillable queue depend on type and sort it to let the highest speed served first,, the first new function in phase 2

	void RemoveCookFromBreak(int);  //remove the cook from break queue after finishing his break // MOSTAFA

	void RemoveOrderFromCook(int);  //remove order to finish and put the cook in approbiate queue // Mostafa

	void RemoveOrderFromCookEmergencyCase(int t);

	//second function in new functions of phase 2 //Mostafa Neddal
	void HealthProblem(int x);  //will be handeled in function REMOVE_ORDER_FROM_COOK here we just set speed to half and set the cook injured

	void RemoveCOOKFROMREST(int t);  //remove cooks from rest queue to their queues depending on their type
	
	   //##################-------------------------------###############################
	  //Mostafa Neddal
     //I already generated All random numbers to be calulated 
    //the speed and break time are in cook constructor
   //the INJURYPROP was made in HealthProblem(Queue<Cook*>) 
  //############--------------------------------------#############################

	//FUNCTIONS RELATED TO EVENTS ---------&&&&&&&&----------- by MOSTAFA NEDDAL
	void CancelOrder(int id);
	void Add(Order* o);
	void Promote_with_extra_mony(int id,double p);
	void AutoPromote(int t);
	float Get_Percentageof_Auto_Promot();
	int Count_Waiting_Normal();
	int Count_Waiting_VGN();
	int Count_Waiting_VIP();
	
	//functions by karim
	void SimulationForMODE(int mode); 
	void ActionFunction();
	void PrintingFunction();
};

#endif

