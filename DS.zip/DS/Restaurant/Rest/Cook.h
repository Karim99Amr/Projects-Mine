#pragma once

#include "..\Defs.h"
#include "../LinkedList.h"


class Cook
{
	int ID;
	ORD_TYPE type; //for each order type there is a corresponding type (VIP, Normal, Vegan)
	COOK_TYPE cooktype;
	float speedmin;
	float speedmax; //dishes it can prepare in one clock tick (in one timestep)
	float speed;
	int N, G, V;     // numeber of cooks: N for normal, G for vegan, and V for VIP cooks
	int BO;         //number of orders a cook must prepare before taking a break
  int ordersdone;
	int SN;       //speed of normal cooks
	int SG;      //speed of vegan cooks
	int SV;     //speed of VIP cooks
	//Order* Assigned;
	int Orders;                //number of orders
	int Breakduration;        //break duration (in timesteps) for normal cooks
	int BreakTimeStep;       //the time step he started his break
	int RestTimeStep;       //the time step he started to take rest
	bool inBreak;          //check if cook in break or not
	int RestPeriod;       //the time cook will rest after injury
	float INJPROP;       //the chance to be injured or not in percentage
	bool FIRSTISINJURED;//checks if the cook is injured or not
	int injuryTimestep;   // the time the cook is injured
	bool iscountedbefore; // help to count cooks
	
	//int VIP_WT;//number of ticks before a vip order becomes an urgent order

public:
	Cook();
	Cook(int id, COOK_TYPE b, float maxspeed,float minspeed,int maxorders, int maxbreak,int minbreak,int restper,float injprop);
	virtual ~Cook();

	//setters
	void setID(int);
	void setType(ORD_TYPE);
	void setCookType(COOK_TYPE);
	void setSpeed(float);
	void setN(int);
	void setG(int);
	void setV(int);
	void setBO(int);
	void setordersdone(int);
	void setSN(int);
	void setSG(int);
	void setSV(int);
	void setAssigned();
	void setOrders(int);
	void setsetbreakduration(int);
	void setBreak(bool);
	void SetBreakTimeStep(int);
	void SetRestPeriod(int);
	void SetInjuryProp(float);
	void SetRestTimeStep(int);
	void SetFirstISINJURED(bool x);
	void setinjurytime(int);
	void setiscountedbefore(bool x);
	void setminspeed(float x);
	void setmaxspeed(float);
	//void setVIP_WT(int a);

	//getters
	int GetID()const ;
	ORD_TYPE GetType() const;
	COOK_TYPE GetCookType() const;
	float GetSpeed();
	int GetN();
	int GetG();
	int GetV();
	int GetBO();
	int Getordersdone();
	int GetSN();
	int GetSG();
	int GetSV();
	int GetOrders();
	int getbreakduration();
	bool GetBreak();
	int GetBreakTimeStep();
	int GetRestPeriod();
	float GetInjuryProp();
	int GetRestTimeStep();
	bool CheckFirstISINJURED();
	int getinjurytime();
	bool getiscountedbefore();
	float getminspeed();
	float getmaxspeed();

	//functions
	//bool IsAvailable();  //checks if cook is on a break and if free
	//void AssignCook(Order* O);
	void incrementordersdone();
	int floattoint(float x);
	bool IsInBreak(); 
};
