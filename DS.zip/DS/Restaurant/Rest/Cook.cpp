#include "Cook.h"
#include<cstdlib>
#include<ctime>


Cook::Cook(int a, COOK_TYPE b, float maxspee, float minspee, int maxorders, int maxbreak, int minbreak, int restperiod, float injprop)
{
	srand(time(0));
	ID = a;
	cooktype = b;
	speed = (rand() % floattoint((maxspee - minspee))) + minspee;
	speedmin = minspee;
	speedmax = maxspee;
	Breakduration = (rand() % (maxbreak - minbreak)) + minbreak;
	BO = maxorders;
	RestPeriod = restperiod;
	INJPROP = injprop;
	FIRSTISINJURED = false;
	iscountedbefore = false;
	Orders = 0;
	ordersdone = 0;
}

Cook::Cook()
{
	Orders = 0;
}

Cook::~Cook()
{

}

int Cook::GetID() const
{
	return ID;
}

ORD_TYPE Cook::GetType() const
{
	return type;
}

COOK_TYPE Cook::GetCookType() const
{
	return cooktype;
}

float Cook::GetSpeed()
{
	return speed;
}

int Cook::GetN()
{
	return N;
}

int Cook::GetG()
{
	return G;
}

int Cook::GetV()
{
	return V;
}

int Cook::GetBO()
{
	return BO;
}

int Cook::Getordersdone()
{
	return ordersdone;
}

int Cook::GetSN()
{
	return SN;
}

int Cook::GetSG()
{
	return SG;
}

int Cook::GetSV()
{
	return SV;
}

int Cook::GetOrders()
{
	return Orders;
}

int Cook::getbreakduration()
{
	return Breakduration;
}

bool Cook::GetBreak()
{
	return inBreak;
}

int Cook::GetBreakTimeStep()
{
	return BreakTimeStep;
}

int Cook::GetRestPeriod()
{
	return RestPeriod;
}

float Cook::GetInjuryProp()
{
	return INJPROP;
}

int Cook::GetRestTimeStep()
{
	return RestTimeStep;
}

bool Cook::CheckFirstISINJURED()
{
	return FIRSTISINJURED;
}

int Cook::getinjurytime()
{
	return injuryTimestep;
}

bool Cook::getiscountedbefore()
{
	return iscountedbefore;
}

float Cook::getminspeed()
{
	return speedmin;
}

float Cook::getmaxspeed()
{
	return speedmax;
}

void Cook::setID(int id)
{
	ID = id;
}

void Cook::setType(ORD_TYPE t)
{
	type = t;
}

void Cook::setCookType(COOK_TYPE t)
{
	cooktype = t;
}

void Cook::setSpeed(float x)
{
	speed = x;
}

void Cook::setN(int n)
{
	N = n;
}

void Cook::setG(int g)
{
	G = g;
}

void Cook::setV(int v)
{
	V = v;
}

void Cook::setBO(int B)
{
	BO = B;
}

void Cook::setordersdone(int o)
{
	ordersdone = o;
}

void Cook::setSN(int sn)
{
	SN = sn;
}

void Cook::setSG(int sg)
{
	SG = sg;
}

void Cook::setSV(int sv)
{
	SV = sv;
}

void Cook::setAssigned()
{

}

void Cook::setOrders(int n)
{
	Orders = n;
}

void Cook::setsetbreakduration(int c) 
{
	Breakduration = c;
}

void Cook::setBreak(bool b)
{
	inBreak = b;
}

void Cook::SetBreakTimeStep(int c)
{
	BreakTimeStep = c;
}

void Cook::SetRestPeriod(int c)
{
	RestPeriod = c;
}

void Cook::SetInjuryProp(float k)
{
	INJPROP = k;
}

void Cook::SetRestTimeStep(int r)
{
	RestTimeStep = r;
}

void Cook::SetFirstISINJURED(bool x)
{
	FIRSTISINJURED = x;
}

void Cook::setinjurytime(int t)
{
	injuryTimestep = t;
}

void Cook::setiscountedbefore(bool y)
{
	iscountedbefore = y;
}

void Cook::setminspeed(float x)
{
	speedmin = x;
}

void Cook::setmaxspeed(float x)
{
	speedmax = x;
}

/*bool Cook::IsAvailable()
{
	if (Assigned != nullptr)  //check if cook is on a break?
	{
			return false;
	}
	if (ordersdone % BO == 0)
	{
		return false;
	}
	return true;
}*/

/*void Cook::AssignCook(Order* O)
{
	if (IsAvailable())
	{
		Assigned = O;
	}
}*/

void Cook::incrementordersdone()
{
	ordersdone = ordersdone + 1;
}

int Cook::floattoint(float x)
{
	int temp = x;
	return temp;
}

bool Cook::IsInBreak()
{
	if (inBreak)
	{
		return true;
	}
	return false;
}
