#include "ArrivalEvent.h"
#include "..\Rest\Restaurant.h"


ArrivalEvent::ArrivalEvent(int TS, int ID, ORD_TYPE type, int Size, int Money, int x) :Event(TS, ID)
{
	OrdType = type;
	size = Size;
	OrdMoney = Money;
	VIP_WT = x;
}

/*
ArrivalEvent::ArrivalEvent(int eTime, int oID, ORD_TYPE oType, double mony, int distance) : Event(eTime, oID) {
	OrdType = oType;
	OrdMoney = mony;
	OrdDistance = distance;
}*/

double ArrivalEvent::GetOrderMony()
{
	return OrdMoney;
}

void ArrivalEvent::Execute(Restaurant* pRest)
{
	//this function should create an order and fills its data 
	//then adds it to normal, vegan, or VIP order lists that you will create in phase1
	Order* ptr = new Order(OrderID, OrdType,VIP_WT);
	ptr->SetOrderSize(size);
	ptr->SetTotalMoney(OrdMoney);
	ptr->setID(OrderID);
	//ptr->setautopromote(autopromotetime);
	ptr->set_VIPWT(VIP_WT);
	ptr->SetType(OrdType);
	ptr->SetArrTime(EventTime);
	ptr->setStatus(WAIT);
	pRest->Add(ptr);
}
