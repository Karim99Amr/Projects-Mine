#ifndef __EVENT_H_
#define __EVENT_H_

#include "..\Defs.h"


class Restaurant;	//forward declation

//the base class for all possible events in the system (abstract class)
class Event
{
protected:
	int EventTime;	 //timestep when this event takes place
	int OrderID;	//each event is related to certain order
	char type;

public:
	Event();
	Event(int eTime, int ordID);
	int getEventTime();
	int getOrderID();
	virtual ~Event();
	char getType();

	virtual void Execute(Restaurant* pRest) = 0;	//a pointer to "Restaurant" and events need it to execute
};

#endif
