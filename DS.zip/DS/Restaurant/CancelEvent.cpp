#include "CancelEvent.h"
#include"Rest\Restaurant.h"
#include "Rest\Order.h"


CancelEvent::CancelEvent(int ts, int id) : Event(ts, id)
{

}

//Next Func cancel the requested order if Found
void CancelEvent::Execute(Restaurant* pRest)
{
	pRest->CancelOrder(OrderID);
}
