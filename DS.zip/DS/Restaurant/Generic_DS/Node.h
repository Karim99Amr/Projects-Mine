#ifndef __NODE_H_
#define __NODE_H_


template < typename T>
class Node
{
private :
	float priority;
	T item; //a data item
	Node<T>* next; //pointer to next node

public :
	Node();
	Node( const T & r_Item);	//passing by const ref.
	Node( const T & r_Item, Node<T>* nextNodePtr);
	void setItem( const T & r_Item);
	void setNext(Node<T>* nextNodePtr);
	T getItem() const ;
	void setpriority( float item);
	float getpriority();
	Node<T>* getNext() const;

}; //end Node


template < typename T>
Node<T>::Node() 
{
	next = nullptr;
} 

template < typename T>
Node<T>::Node( const T& r_Item)
{
	item = r_Item;
	next = nullptr;
} 

template < typename T>
Node<T>::Node(const T& r_Item, Node<T>* nextNodePtr)
{
	item = r_Item;
	next = nextNodePtr;
}

template < typename T>
void Node<T>::setItem(const T& r_Item)
{
	item = r_Item;
}

template < typename T>
void Node<T>::setNext(Node<T>* nextNodePtr)
{
	next = nextNodePtr;
} 

template < typename T>
T Node<T>::getItem() const
{
	return item;
} 

template < typename T>
Node<T>* Node<T>::getNext() const
{
	return next;
} 

template<typename T>
void Node<T>::setpriority(float item)
{
	priority = item;
}

template<typename T>
float Node<T>::getpriority() 
{
	return priority;
}

#endif
