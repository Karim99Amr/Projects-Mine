#pragma once

#ifndef __LINKEDLIST_
#define __LINKEDLIST_

#include"Node.h"

template <typename T>
class LinkedList
{
private:
	Node<T>* Head;	//Pointer to the head of the list

	//You can add tail pointer too (depending on your problem)
public:


	LinkedList()
	{
		Head = nullptr;
	}

	//List is being desturcted ==> delete all items in the list
	~LinkedList()
	{
		DeleteAll();
	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: PrintList.
	* prints the values of all nodes in a linked list.
	*/
	void PrintList()	const
	{
		Node<T>* p = Head;

		while (p)
		{
			cout << p->getItem();
			cout << " ";
			p = p->getNext();
		}
		cout << " ";
	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: InsertBeg.
	* Creates a new node and adds it to the beginning of a linked list.
	*
	* Parameters:
	*	- data : The value to be stored in the new node.
	*/
	void InsertBeg(const T& data)
	{
		Node<T>* R = new Node<T>(data);
		R->setNext(Head);
		Head = R;

	}
	////////////////////////////////////////////////////////////////////////
	/*
	* Function: DeleteAll.
	* Deletes all nodes of the list.
	*/
	void DeleteAll()
	{
		Node<T>* P = Head;
		while (Head)
		{
			P = Head->getNext();
			delete Head;
			Head = P;
		}
	}



	////////////////     Requirements   ///////////////////
	//
	// Implement the following member functions


	//[1]InsertEnd 
	//inserts a new node at end if the list
	void InsertEnd(const T& data)
	{
		Node<T>* ptr = Head;
		if (!Head) {
			InsertBeg(data);
			return;
		}
		while (ptr->getNext() != nullptr) {
			ptr = ptr->getNext();
		}
		Node<T>* neww = new Node<T>(data);
		ptr->setNext(neww);

	}

	//[2]Find 
	//searches for a given value in the list, returns true if found; false otherwise.
	bool Find(int Key) {
		bool x = false;
		Node<int>* ptr = Head;

		while (Head) {
			if (ptr->getItem() == Key) {
				x = true;
				cout << "found";
				break;
			}
			//	else  ptr = ptr->getNext();
				//if (ptr->getItem() != Key) {
				//	cout << "no values";
			//	}
		}
		return x;
	}

	//[3]CountOccurance
	//returns how many times a certain value appeared in the list
	int CountOccurance(const T& value) {
		int count = 0;
		Node<T>* ptr = Head;
		while (ptr != nullptr) {
			if (ptr->getItem() == value) {
				count++;
				ptr = ptr->getNext();
			}
			else ptr = ptr->getNext();
		}
		cout << "occur" << count << "times" << endl;
		return count;

	}

	//[4] DeleteFirst
	//Deletes the first node in the list
	void DeleteFirst() {
		Node<T>* ptr = Head;
		Node<T>* ptr2 = Head;
		Node<T>* temp = new Node<T>;
		if (ptr == nullptr) {
			return;
		}
		temp = ptr;
		temp = nullptr;
		delete temp;

		Head = Head->getNext();
	}


	//[5] DeleteLast
	//Deletes the last node in the list
	void DeleteLast() {
		Node<T>* ptr = Head;
		Node<T>* temp = new Node<T>;
		if (ptr == nullptr) {
			return;
		}
		while (ptr->getNext()->getNext() != nullptr) {
			ptr = ptr->getNext();
		}
		temp = ptr->getNext();
		temp = nullptr;
		delete temp;
		ptr->setNext(nullptr);
	}

	//[6] DeleteNode
	//deletes the first node with the given value (if found) and returns true
	//if not found, returns false
	//Note: List is not sorted

	bool DeleteNode(const T& value) {
		bool x = false;
		Node<T>* ptr = Head;
		Node<T>* temp = new Node<T>;
		if (ptr == 0) {
			return 0;
		}
		while (ptr->getNext()->getItem() != value) {
			ptr = ptr->getNext();
		}
		//if (!(ptr == Head)) {
		x = true;
		temp = ptr->getNext();
		temp = nullptr;
		delete temp;
		ptr->setNext(ptr->getNext()->getNext());

		return x;
	}
	void AddVipOrder(const T& ord, float p) {
		Node<T>* prev;
		Node<T>* ptr = Head;
		Node<T>* t = new Node<T>(ord);
		t->SetPriority(p);
		if (!Head) {
			t = Head;
			t->setNext(nullptr);
			return;
		}

		else if (t->GetPiority() > ptr->GetPiority())
		{
			t->setNext(ptr);
			t = Head;
			t = ptr;
		}
		else
		{

			while (ptr && ptr->GetPiority() >= p)
			{
				prev = ptr;
				ptr = ptr->getNext();
			}
			if (ptr) {
				prev->setNext(t);
				t->setNext(ptr);
			}
			if (!ptr) {
				prev->setNext(t);
				t->setNext(nullptr);
			}

		}
	}
};
#endif
