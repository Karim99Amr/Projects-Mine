#ifndef __DEFS_H_
#define __DEFS_H_


enum ORD_TYPE	//types of orders
{
	TYPE_NRM,	 //normal order
	TYPE_VGAN,  //vegan
	TYPE_VIP,  //VIP
	TYPE_CNT  //number of types
};

//Nermeen
enum COOK_TYPE	//types of cooks
{
	COOK_TYPE_NRM,	  //normal cooks
	COOK_TYPE_VGAN,	 //vegan
	COOK_TYPE_VIP,  //VIP
	COOK_TYPE_CNT  //number of types
};

enum ORD_STATUS	//order status
{
	WAIT,	  //waiting to be served
	SRV,	 //in-service but not delivered (not finished) yet
	DONE,	//delivered (finished) to its destination
	ORD_STATUS_CNT
};

enum PROG_MODE	//mode of the program interface
{
	MODE_INTR,	    //interactive mode
	MODE_STEP,	   //step-by-step mode
	MODE_SLNT,	  //silent mode
	MODE_DEMO,	 //demo mode (for introductory phase only, should be removed in phases 1&2)
	MODE_CNT	//number of possible modes
};

#define MaxPossibleOrdCnt 999	//max possible order count (arbitrary value)
#define MaxPossibleMcCnt  100	//max possible cook count (arbitrary value)

#endif
