#pragma once

#ifndef __PROMPTE_EVENT_H_
#define __PROMPTE_EVENT_H_
#include"Events/Event.h"
#include"Events/ArrivalEvent.h"
#include "Rest\Order.h"


class PrompteEvent : public Event
{
	ORD_TYPE Order_Type;     //must be a normal order
	double Extra_Mony;        //money added to promote
	double totalmony;

public:
	//PrompteEvent();
	PrompteEvent(int et, int id, double extra);
	//void setautopromotion(int i);
	void Execute(Restaurant* ptr);
};

#endif
